import sqlite3
import hashlib
import os

DB_PATH = 'maruti.db'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if os.path.exists(DB_PATH):
        return
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            role TEXT DEFAULT 'buyer',
            user_type TEXT DEFAULT 'retail',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS brands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            logo TEXT,
            description TEXT
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            brand_id INTEGER,
            category TEXT,
            price REAL NOT NULL,
            wholesale_price REAL NOT NULL,
            stock INTEGER DEFAULT 0,
            description TEXT,
            image TEXT,
            is_featured INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (brand_id) REFERENCES brands(id)
        );
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            product_id INTEGER,
            quantity INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            total_amount REAL,
            payment_method TEXT DEFAULT 'cod',
            shipping_address TEXT,
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            product_id INTEGER,
            quantity INTEGER,
            price REAL,
            FOREIGN KEY (order_id) REFERENCES orders(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS enquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            phone TEXT,
            product TEXT,
            quantity INTEGER DEFAULT 1,
            message TEXT,
            user_id INTEGER,
            status TEXT DEFAULT 'new',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            phone TEXT,
            message TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    """)

    # Seed data
    pw = hashlib.sha256('admin123'.encode()).hexdigest()
    db.execute("INSERT INTO users (name,email,password,role,user_type) VALUES ('Admin','admin@maruti.com',?,'admin','retail')", (pw,))
    pw2 = hashlib.sha256('buyer123'.encode()).hexdigest()
    db.execute("INSERT INTO users (name,email,password,phone,address,role,user_type) VALUES ('Rahul Shah','rahul@example.com',?,'9876543210','Ahmedabad, Gujarat','buyer','retail')", (pw2,))
    pw3 = hashlib.sha256('wholesale123'.encode()).hexdigest()
    db.execute("INSERT INTO users (name,email,password,phone,address,role,user_type) VALUES ('Mehta Electricals','mehta@example.com',?,'9988776655','Surat, Gujarat','buyer','wholesale')", (pw3,))

    brands = [
        ('HiFi', '', 'Premium quality electrical products by HiFi brand'),
        ('Elleys', '', 'Elleys - Trusted name in electrical fittings'),
        ('House of Ollo', '', 'Modern and stylish electrical solutions'),
        ('Orbit', '', 'Orbit electrical products for every need'),
    ]
    for b in brands:
        db.execute("INSERT INTO brands (name,logo,description) VALUES (?,?,?)", b)

    products = [
        ('HiFi LED Bulb 9W', 1, 'LED Bulbs', 85, 62, 500, 'Energy-saving 9W LED bulb with warm white light. Long life 25000 hours.', 'https://via.placeholder.com/300x300/FF6B35/white?text=HiFi+LED+9W', 1),
        ('HiFi LED Bulb 12W', 1, 'LED Bulbs', 110, 82, 400, 'Bright 12W LED bulb ideal for large rooms. Energy efficient.', 'https://via.placeholder.com/300x300/FF6B35/white?text=HiFi+LED+12W', 1),
        ('HiFi MCB 32A', 1, 'MCB', 320, 245, 200, 'Miniature Circuit Breaker 32A single pole for home and office use.', 'https://via.placeholder.com/300x300/2D3748/white?text=HiFi+MCB', 1),
        ('HiFi Switch 6A', 1, 'Switches', 45, 32, 1000, 'Standard 6A modular switch, white finish, ISI marked.', 'https://via.placeholder.com/300x300/FF6B35/white?text=HiFi+Switch', 1),
        ('Elleys Anchor Socket 16A', 2, 'Sockets', 95, 72, 800, 'ISI marked 16A 3-pin socket with safety shutter. Modular type.', 'https://via.placeholder.com/300x300/E53E3E/white?text=Elleys+Socket', 1),
        ('Elleys Fan Regulator', 2, 'Regulators', 180, 140, 300, 'Electronic fan speed regulator, energy saving, compatible with all fans.', 'https://via.placeholder.com/300x300/E53E3E/white?text=Elleys+Reg', 1),
        ('Elleys 4-Way Extension', 2, 'Extension Boards', 350, 270, 150, '4-way extension board with 6A and 16A sockets, master switch, 1.5m cord.', 'https://via.placeholder.com/300x300/805AD5/white?text=Elleys+Ext', 1),
        ('House of Ollo Designer Switch', 3, 'Switches', 220, 170, 400, 'Premium designer modular switch, glass finish, touch sensitive.', 'https://via.placeholder.com/300x300/38A169/white?text=Ollo+Switch', 1),
        ('House of Ollo LED Panel 18W', 3, 'LED Panels', 650, 510, 200, 'Slim LED panel light 18W, cool white, suitable for false ceiling.', 'https://via.placeholder.com/300x300/38A169/white?text=Ollo+Panel', 0),
        ('Orbit Wire 1.5sqmm (90m)', 4, 'Wires & Cables', 1200, 950, 100, 'Flexible PVC insulated copper wire 1.5 sq mm, 90 meter coil.', 'https://via.placeholder.com/300x300/3182CE/white?text=Orbit+Wire', 0),
        ('Orbit Wire 2.5sqmm (90m)', 4, 'Wires & Cables', 1850, 1480, 100, 'Heavy duty PVC insulated copper wire 2.5 sq mm, 90 meter coil.', 'https://via.placeholder.com/300x300/3182CE/white?text=Orbit+Wire', 0),
        ('Orbit Distribution Box 8-way', 4, 'DB Boxes', 780, 620, 80, '8-way distribution box with DIN rail, powder coated steel.', 'https://via.placeholder.com/300x300/3182CE/white?text=Orbit+DB', 0),
        ('HiFi Tube Light 20W', 1, 'Tube Lights', 290, 225, 300, '20W LED tube light, 4 feet, cool daylight, energy efficient.', 'https://via.placeholder.com/300x300/FF6B35/white?text=HiFi+Tube', 0),
        ('Elleys RCCB 40A', 2, 'RCCB', 850, 680, 60, 'Residual Current Circuit Breaker 40A 30mA, double pole.', 'https://via.placeholder.com/300x300/E53E3E/white?text=Elleys+RCCB', 0),
        ('House of Ollo Modular Plate', 3, 'Accessories', 125, 98, 500, 'Premium modular plate 3-module, white glossy finish.', 'https://via.placeholder.com/300x300/38A169/white?text=Ollo+Plate', 0),
    ]
    for p in products:
        db.execute("INSERT INTO products (name,brand_id,category,price,wholesale_price,stock,description,image,is_featured) VALUES (?,?,?,?,?,?,?,?,?)", p)

    db.commit()
    db.close()
    print("✅ Database initialized with seed data.")
