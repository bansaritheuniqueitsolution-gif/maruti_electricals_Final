#!/bin/bash
echo "=========================================="
echo "  MARUTI ELECTRICALS - Starting Server"
echo "=========================================="
echo ""
echo "Installing dependencies..."
pip install flask --quiet
echo ""
echo "Starting Flask server..."
echo "Open your browser and go to: http://127.0.0.1:5000"
echo ""
echo "Admin Login:  admin@maruti.com   / admin123"
echo "Buyer Login:  rahul@example.com  / buyer123"
echo "Wholesale:    mehta@example.com  / wholesale123"
echo ""
python app.py
