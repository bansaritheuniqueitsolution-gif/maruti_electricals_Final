# 🔌 Maruti Electricals – Full E-Commerce Website

A complete electrical products e-commerce website built with **Flask + SQLite + Bootstrap 5**.

---

## 📋 Features

### Pages Included
- ✅ Home Page (Hero, Featured Products, Brands, Categories)
- ✅ Products Page (with search, brand & category filters)
- ✅ Product Detail Page
- ✅ Brands Page
- ✅ Wholesale Page (bulk pricing table)
- ✅ Retail Page (standard pricing table)
- ✅ Contact Page
- ✅ Enquiry Page
- ✅ Login Page (Admin & Buyer)
- ✅ Signup Page (Retail & Wholesale account types)
- ✅ Buyer Dashboard
- ✅ Cart Page
- ✅ Checkout Page
- ✅ My Orders Page
- ✅ Order Detail Page
- ✅ Admin Dashboard (with stats)
- ✅ Admin: Products (List, Add, Edit, Delete)
- ✅ Admin: Brands (Add, Delete)
- ✅ Admin: Orders (View, Update Status)
- ✅ Admin: Customers
- ✅ Admin: Enquiries (with status update)
- ✅ Admin: Contact Messages

### Business Features
- 🏷️ Dual pricing: Retail & Wholesale rates (auto-applied based on account type)
- 💳 Payment methods: COD, Online, EMI
- 🛒 Cart & Checkout system
- 📦 Order tracking with status updates
- 📬 Enquiry & Contact forms
- 🔐 Role-based login: Admin & Buyer
- 🏢 Brands: HiFi, Elleys, House of Ollo, Orbit

---

## 🚀 How to Run

### Requirements
- Python 3.8 or higher
- pip (comes with Python)

### Step-by-Step Setup

#### Windows
1. Extract the ZIP file
2. Double-click `run.bat`
   - OR open Command Prompt in the folder and run: `python app.py`
3. Open browser → http://127.0.0.1:5000

#### Mac / Linux
1. Extract the ZIP file
2. Open Terminal in the project folder
3. Run: `chmod +x run.sh && ./run.sh`
   - OR just: `pip install flask && python app.py`
4. Open browser → http://127.0.0.1:5000

---

## 🔑 Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@maruti.com | admin123 |
| Retail Buyer | rahul@example.com | buyer123 |
| Wholesale Buyer | mehta@example.com | wholesale123 |

---

## 📁 Project Structure

```
maruti_electricals/
├── app.py              ← Main Flask application
├── database.py         ← DB setup & seed data
├── maruti.db           ← SQLite database (auto-created)
├── requirements.txt    ← Python dependencies
├── run.bat             ← Windows startup script
├── run.sh              ← Mac/Linux startup script
├── static/
│   ├── css/
│   │   └── style.css   ← All custom styles
│   └── js/
│       └── main.js     ← JavaScript helpers
└── templates/
    ├── base.html        ← Public layout (navbar, footer)
    ├── home.html
    ├── products.html
    ├── product_detail.html
    ├── brands.html
    ├── wholesale.html
    ├── retail.html
    ├── contact.html
    ├── enquiry.html
    ├── login.html
    ├── signup.html
    ├── dashboard.html
    ├── cart.html
    ├── checkout.html
    ├── my_orders.html
    ├── order_detail.html
    └── admin/
        ├── base.html    ← Admin layout (sidebar)
        ├── dashboard.html
        ├── products.html
        ├── add_product.html
        ├── edit_product.html
        ├── brands.html
        ├── orders.html
        ├── users.html
        ├── enquiries.html
        └── contacts.html
```

---

## ⚙️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Bootstrap 5.3, Font Awesome 6 |
| Backend | Python 3, Flask 3.0 |
| Database | SQLite (via Python's sqlite3) |
| Fonts | Google Fonts (Rajdhani + Inter) |

---

## 📝 Notes for Internship

- The website is fully functional and ready to present
- SQLite DB is auto-created on first run with sample data
- To reset the database, delete `maruti.db` and restart
- All passwords are SHA-256 hashed
- Wholesale pricing auto-applies when user account type is 'wholesale'

---

*Built for Maruti Electricals – Ahmedabad, Gujarat | Authorized Dealer: HiFi & Elleys*
