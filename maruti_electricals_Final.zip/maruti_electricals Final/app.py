from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from database import init_db, get_db
import hashlib
import os

app = Flask(__name__)
app.secret_key = 'maruti_electricals_secret_2024'

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ─── PUBLIC ROUTES ───────────────────────────────────────────────────────────

@app.route('/')
def home():
    db = get_db()
    featured = db.execute("SELECT * FROM products WHERE is_featured=1 LIMIT 8").fetchall()
    brands   = db.execute("SELECT * FROM brands").fetchall()
    return render_template('home.html', featured=featured, brands=brands)

@app.route('/products')
def products():
    db = get_db()
    brand_filter    = request.args.get('brand', '')
    category_filter = request.args.get('category', '')
    search          = request.args.get('search', '')
    query = "SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON p.brand_id=b.id WHERE 1=1"
    params = []
    if brand_filter:
        query += " AND b.name=?"; params.append(brand_filter)
    if category_filter:
        query += " AND p.category=?"; params.append(category_filter)
    if search:
        query += " AND p.name LIKE ?"; params.append(f'%{search}%')
    prods      = db.execute(query, params).fetchall()
    brands     = db.execute("SELECT * FROM brands").fetchall()
    categories = db.execute("SELECT DISTINCT category FROM products").fetchall()
    return render_template('products.html', products=prods, brands=brands,
                           categories=categories, brand_filter=brand_filter,
                           category_filter=category_filter, search=search)

@app.route('/product/<int:pid>')
def product_detail(pid):
    db   = get_db()
    prod = db.execute("SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON p.brand_id=b.id WHERE p.id=?", (pid,)).fetchone()
    if not prod:
        flash('Product not found.', 'danger'); return redirect(url_for('products'))
    related = db.execute("SELECT * FROM products WHERE brand_id=? AND id!=? LIMIT 4", (prod['brand_id'], pid)).fetchall()
    return render_template('product_detail.html', product=prod, related=related)

@app.route('/brands')
def brands():
    db = get_db()
    all_brands = db.execute("SELECT b.*, COUNT(p.id) as product_count FROM brands b LEFT JOIN products p ON b.id=p.brand_id GROUP BY b.id").fetchall()
    return render_template('brands.html', brands=all_brands)

@app.route('/wholesale')
def wholesale():
    db = get_db()
    prods = db.execute("SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON p.brand_id=b.id").fetchall()
    return render_template('wholesale.html', products=prods)

@app.route('/retail')
def retail():
    db = get_db()
    prods = db.execute("SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON p.brand_id=b.id").fetchall()
    return render_template('retail.html', products=prods)

@app.route('/contact', methods=['GET','POST'])
def contact():
    if request.method == 'POST':
        db = get_db()
        db.execute("INSERT INTO contacts (name,email,phone,message) VALUES (?,?,?,?)",
                   (request.form['name'], request.form['email'], request.form.get('phone',''), request.form['message']))
        db.commit()
        flash('Message sent! We will contact you soon.', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html')

@app.route('/enquiry', methods=['GET','POST'])
def enquiry():
    if request.method == 'POST':
        db = get_db()
        db.execute("INSERT INTO enquiries (name,email,phone,product,quantity,message,user_id) VALUES (?,?,?,?,?,?,?)",
                   (request.form['name'], request.form['email'], request.form.get('phone',''),
                    request.form.get('product',''), request.form.get('quantity',1),
                    request.form['message'], session.get('user_id')))
        db.commit()
        flash('Enquiry submitted successfully!', 'success')
        return redirect(url_for('enquiry'))
    db    = get_db()
    prods = db.execute("SELECT * FROM products").fetchall()
    return render_template('enquiry.html', products=prods)

# ─── AUTH ────────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        db   = get_db()
        user = db.execute("SELECT * FROM users WHERE email=? AND password=?",
                          (request.form['email'], hash_password(request.form['password']))).fetchone()
        if user:
            session['user_id']  = user['id']
            session['username'] = user['name']
            session['role']     = user['role']
            session['user_type']= user['user_type']
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('admin_dashboard') if user['role']=='admin' else url_for('dashboard'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        db = get_db()
        existing = db.execute("SELECT id FROM users WHERE email=?", (request.form['email'],)).fetchone()
        if existing:
            flash('Email already registered.', 'danger')
            return redirect(url_for('signup'))
        db.execute("INSERT INTO users (name,email,password,phone,address,role,user_type) VALUES (?,?,?,?,?,?,?)",
                   (request.form['name'], request.form['email'], hash_password(request.form['password']),
                    request.form.get('phone',''), request.form.get('address',''),
                    'buyer', request.form.get('user_type','retail')))
        db.commit()
        flash('Account created! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('home'))

# ─── BUYER ROUTES ────────────────────────────────────────────────────────────

@app.route('/dashboard')
@login_required
def dashboard():
    db     = get_db()
    orders = db.execute("SELECT o.*, COUNT(oi.id) as item_count FROM orders o LEFT JOIN order_items oi ON o.id=oi.order_id WHERE o.user_id=? GROUP BY o.id ORDER BY o.created_at DESC LIMIT 5", (session['user_id'],)).fetchall()
    user   = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    return render_template('dashboard.html', orders=orders, user=user)

@app.route('/cart')
@login_required
def cart():
    db    = get_db()
    items = db.execute("""SELECT c.*, p.name, p.price, p.wholesale_price, p.image, b.name as brand_name
                          FROM cart c JOIN products p ON c.product_id=p.id JOIN brands b ON p.brand_id=b.id
                          WHERE c.user_id=?""", (session['user_id'],)).fetchall()
    user  = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    total = 0
    for item in items:
        price = item['wholesale_price'] if user['user_type']=='wholesale' else item['price']
        total += price * item['quantity']
    return render_template('cart.html', items=items, total=total, user=user)

@app.route('/add_to_cart/<int:pid>', methods=['POST'])
@login_required
def add_to_cart(pid):
    db  = get_db()
    qty = int(request.form.get('quantity', 1))
    existing = db.execute("SELECT * FROM cart WHERE user_id=? AND product_id=?", (session['user_id'], pid)).fetchone()
    if existing:
        db.execute("UPDATE cart SET quantity=quantity+? WHERE user_id=? AND product_id=?", (qty, session['user_id'], pid))
    else:
        db.execute("INSERT INTO cart (user_id, product_id, quantity) VALUES (?,?,?)", (session['user_id'], pid, qty))
    db.commit()
    flash('Added to cart!', 'success')
    return redirect(request.referrer or url_for('products'))

@app.route('/remove_from_cart/<int:cid>')
@login_required
def remove_from_cart(cid):
    db = get_db()
    db.execute("DELETE FROM cart WHERE id=? AND user_id=?", (cid, session['user_id']))
    db.commit()
    return redirect(url_for('cart'))

@app.route('/update_cart/<int:cid>', methods=['POST'])
@login_required
def update_cart(cid):
    db  = get_db()
    qty = int(request.form.get('quantity', 1))
    if qty < 1:
        db.execute("DELETE FROM cart WHERE id=? AND user_id=?", (cid, session['user_id']))
    else:
        db.execute("UPDATE cart SET quantity=? WHERE id=? AND user_id=?", (qty, cid, session['user_id']))
    db.commit()
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET','POST'])
@login_required
def checkout():
    db   = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    items = db.execute("""SELECT c.*, p.name, p.price, p.wholesale_price, p.image
                          FROM cart c JOIN products p ON c.product_id=p.id
                          WHERE c.user_id=?""", (session['user_id'],)).fetchall()
    if not items:
        flash('Your cart is empty.', 'warning')
        return redirect(url_for('cart'))
    total = sum((i['wholesale_price'] if user['user_type']=='wholesale' else i['price'])*i['quantity'] for i in items)
    if request.method == 'POST':
        payment = request.form.get('payment_method','cod')
        address = request.form.get('address', user['address'])
        order_id = db.execute("INSERT INTO orders (user_id,total_amount,payment_method,shipping_address,status) VALUES (?,?,?,?,?)",
                              (session['user_id'], total, payment, address, 'pending')).lastrowid
        for item in items:
            price = item['wholesale_price'] if user['user_type']=='wholesale' else item['price']
            db.execute("INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)",
                       (order_id, item['product_id'], item['quantity'], price))
        db.execute("DELETE FROM cart WHERE user_id=?", (session['user_id'],))
        db.commit()
        flash(f'Order #{order_id} placed successfully!', 'success')
        return redirect(url_for('my_orders'))
    return render_template('checkout.html', items=items, total=total, user=user)

@app.route('/my_orders')
@login_required
def my_orders():
    db     = get_db()
    orders = db.execute("""SELECT o.*, COUNT(oi.id) as item_count FROM orders o
                           LEFT JOIN order_items oi ON o.id=oi.order_id
                           WHERE o.user_id=? GROUP BY o.id ORDER BY o.created_at DESC""",
                        (session['user_id'],)).fetchall()
    return render_template('my_orders.html', orders=orders)

@app.route('/order/<int:oid>')
@login_required
def order_detail(oid):
    db    = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=? AND user_id=?", (oid, session['user_id'])).fetchone()
    if not order:
        flash('Order not found.', 'danger'); return redirect(url_for('my_orders'))
    items = db.execute("""SELECT oi.*, p.name, p.image, b.name as brand_name
                          FROM order_items oi JOIN products p ON oi.product_id=p.id
                          JOIN brands b ON p.brand_id=b.id WHERE oi.order_id=?""", (oid,)).fetchall()
    return render_template('order_detail.html', order=order, items=items)

# ─── ADMIN ROUTES ────────────────────────────────────────────────────────────

@app.route('/admin')
@admin_required
def admin_dashboard():
    db = get_db()
    stats = {
        'total_orders':    db.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
        'total_users':     db.execute("SELECT COUNT(*) FROM users WHERE role='buyer'").fetchone()[0],
        'total_products':  db.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        'total_revenue':   db.execute("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status!='cancelled'").fetchone()[0],
        'pending_orders':  db.execute("SELECT COUNT(*) FROM orders WHERE status='pending'").fetchone()[0],
        'new_enquiries':   db.execute("SELECT COUNT(*) FROM enquiries WHERE status='new'").fetchone()[0],
    }
    recent_orders = db.execute("SELECT o.*, u.name as user_name FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC LIMIT 8").fetchall()
    return render_template('admin/dashboard.html', stats=stats, recent_orders=recent_orders)

@app.route('/admin/products')
@admin_required
def admin_products():
    db    = get_db()
    prods = db.execute("SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON p.brand_id=b.id ORDER BY p.id DESC").fetchall()
    return render_template('admin/products.html', products=prods)

@app.route('/admin/products/add', methods=['GET','POST'])
@admin_required
def admin_add_product():
    db = get_db()
    if request.method == 'POST':
        db.execute("""INSERT INTO products (name,brand_id,category,price,wholesale_price,stock,description,image,is_featured)
                      VALUES (?,?,?,?,?,?,?,?,?)""",
                   (request.form['name'], request.form['brand_id'], request.form['category'],
                    request.form['price'], request.form['wholesale_price'], request.form['stock'],
                    request.form['description'], request.form.get('image',''), int(request.form.get('is_featured',0))))
        db.commit()
        flash('Product added!', 'success')
        return redirect(url_for('admin_products'))
    brands = db.execute("SELECT * FROM brands").fetchall()
    return render_template('admin/add_product.html', brands=brands)

@app.route('/admin/products/edit/<int:pid>', methods=['GET','POST'])
@admin_required
def admin_edit_product(pid):
    db   = get_db()
    prod = db.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    if request.method == 'POST':
        db.execute("""UPDATE products SET name=?,brand_id=?,category=?,price=?,wholesale_price=?,
                      stock=?,description=?,image=?,is_featured=? WHERE id=?""",
                   (request.form['name'], request.form['brand_id'], request.form['category'],
                    request.form['price'], request.form['wholesale_price'], request.form['stock'],
                    request.form['description'], request.form.get('image',''),
                    int(request.form.get('is_featured',0)), pid))
        db.commit()
        flash('Product updated!', 'success')
        return redirect(url_for('admin_products'))
    brands = db.execute("SELECT * FROM brands").fetchall()
    return render_template('admin/edit_product.html', product=prod, brands=brands)

@app.route('/admin/products/delete/<int:pid>')
@admin_required
def admin_delete_product(pid):
    db = get_db()
    db.execute("DELETE FROM products WHERE id=?", (pid,))
    db.commit()
    flash('Product deleted.', 'info')
    return redirect(url_for('admin_products'))

@app.route('/admin/brands', methods=['GET','POST'])
@admin_required
def admin_brands():
    db = get_db()
    if request.method == 'POST':
        db.execute("INSERT INTO brands (name,logo,description) VALUES (?,?,?)",
                   (request.form['name'], request.form.get('logo',''), request.form.get('description','')))
        db.commit()
        flash('Brand added!', 'success')
    brands = db.execute("SELECT b.*, COUNT(p.id) as product_count FROM brands b LEFT JOIN products p ON b.id=p.brand_id GROUP BY b.id").fetchall()
    return render_template('admin/brands.html', brands=brands)

@app.route('/admin/brands/delete/<int:bid>')
@admin_required
def admin_delete_brand(bid):
    db = get_db()
    db.execute("DELETE FROM brands WHERE id=?", (bid,))
    db.commit()
    flash('Brand deleted.', 'info')
    return redirect(url_for('admin_brands'))

@app.route('/admin/orders')
@admin_required
def admin_orders():
    db     = get_db()
    status = request.args.get('status','')
    query  = "SELECT o.*, u.name as user_name, u.email FROM orders o JOIN users u ON o.user_id=u.id"
    params = []
    if status:
        query += " WHERE o.status=?"; params.append(status)
    query += " ORDER BY o.created_at DESC"
    orders = db.execute(query, params).fetchall()
    return render_template('admin/orders.html', orders=orders, status_filter=status)

@app.route('/admin/orders/update/<int:oid>', methods=['POST'])
@admin_required
def admin_update_order(oid):
    db = get_db()
    db.execute("UPDATE orders SET status=? WHERE id=?", (request.form['status'], oid))
    db.commit()
    flash('Order status updated!', 'success')
    return redirect(url_for('admin_orders'))

@app.route('/admin/users')
@admin_required
def admin_users():
    db    = get_db()
    users = db.execute("SELECT * FROM users WHERE role='buyer' ORDER BY id DESC").fetchall()
    return render_template('admin/users.html', users=users)

@app.route('/admin/enquiries')
@admin_required
def admin_enquiries():
    db         = get_db()
    enquiries  = db.execute("SELECT * FROM enquiries ORDER BY created_at DESC").fetchall()
    return render_template('admin/enquiries.html', enquiries=enquiries)

@app.route('/admin/enquiries/update/<int:eid>', methods=['POST'])
@admin_required
def admin_update_enquiry(eid):
    db = get_db()
    db.execute("UPDATE enquiries SET status=? WHERE id=?", (request.form['status'], eid))
    db.commit()
    return redirect(url_for('admin_enquiries'))

@app.route('/admin/contacts')
@admin_required
def admin_contacts():
    db       = get_db()
    contacts = db.execute("SELECT * FROM contacts ORDER BY created_at DESC").fetchall()
    return render_template('admin/contacts.html', contacts=contacts)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
