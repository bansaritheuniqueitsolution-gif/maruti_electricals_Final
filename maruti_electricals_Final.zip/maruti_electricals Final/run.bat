@echo off
echo ==========================================
echo   MARUTI ELECTRICALS - Starting Server
echo ==========================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found! Please install Python 3.8 or higher.
    pause
    exit /b
)

:: Install dependencies if needed
echo Installing dependencies...
pip install flask --quiet

:: Delete old DB to reinitialize (remove this line after first run)
:: del maruti.db

echo.
echo Starting Flask server...
echo Open your browser and go to: http://127.0.0.1:5000
echo.
echo Admin Login:  admin@maruti.com   / admin123
echo Buyer Login:  rahul@example.com  / buyer123
echo Wholesale:    mehta@example.com  / wholesale123
echo.
echo Press Ctrl+C to stop the server.
echo.
python app.py
pause
