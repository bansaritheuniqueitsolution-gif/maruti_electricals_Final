// Auto-dismiss alerts after 4 seconds
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(a => {
            let bsAlert = bootstrap.Alert.getOrCreateInstance(a);
            bsAlert.close();
        });
    }, 4000);

    // Animate stat numbers
    document.querySelectorAll('.stat-num[data-val]').forEach(el => {
        let target = parseFloat(el.dataset.val);
        let isFloat = target % 1 !== 0;
        let start = 0, duration = 1200;
        let startTime = null;
        function animate(ts) {
            if (!startTime) startTime = ts;
            let progress = Math.min((ts - startTime) / duration, 1);
            let val = progress * target;
            el.textContent = isFloat ? '₹' + val.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',') : Math.floor(val);
            if (progress < 1) requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
    });
});

// Quantity input helpers
function changeQty(btn, delta) {
    let input = btn.parentElement.querySelector('input[type=number]');
    let val = parseInt(input.value) + delta;
    if (val >= 1) input.value = val;
}

// Payment method toggle
document.querySelectorAll('.payment-option input').forEach(radio => {
    radio.addEventListener('change', () => {
        document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('active'));
        radio.closest('.payment-option').classList.add('active');
    });
});
